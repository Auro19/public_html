<html>
<head>
<link rel="stylesheet" href="tabla.css" type="text/css" />
</head>
<?php 
for ($i=1;$i<=14;$i++){
	$res=5*$i;
	if ($res % 2){
		echo '<div id="impar">5*'.$i.'='.$res.'</div>';
	}else{
		echo '<div id="par">5*'.$i.'='.$res.'</div>';
	}
	
}
?>
</html>