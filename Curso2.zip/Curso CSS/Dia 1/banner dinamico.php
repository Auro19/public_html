﻿<?php 
$ban = array();
$ban[0] = 'banner1';
$ban[1] = 'banner2';
$ban[2] = 'banner3';
$ban[3] = 'banner4';
$ban[4] = 'banner5';
$random = rand(0,4);
$banner = $ban[$random];
?>
<html>
<head>
<link rel="stylesheet" href="myCSS.css" type="text/css" />
<title>MyCSS</title>
</head>

<body>

<div  id="container">
    <div id="title">		    </div>
    <div id="banner"><img src="<?php echo $banner?>.jpg"></div>
    
	<div id="mainArea"> 
			<div id="leftArea">
</div>
			<div id="rightArea">
            </div>
  </div>			
	<div id="footer"></div>
</div>

</body>
</html>
