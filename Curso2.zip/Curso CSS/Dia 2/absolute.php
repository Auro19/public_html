<?php
?>
<html>
<head>
<link rel="stylesheet" href="CSS/absolute.css" type="text/css" />
</head>
<body>
<div id="Title"><h1>hola</h1>></div>
<div id="Sponsor">dd</div>
<div id="Footer">dd</div>
<div id="Banner">dd</div>
<div id="Login">dd</div>
<div id="Left">dd</div>
</body>
</html>
