<?php 
$ima = array();
$ima[0] = '100thWindow';
$ima[1] = 'Currupted';
$ima[2] = 'dance';
$ima[3] = 'Robot';
$ima[4] = 'Rocks';
$random = rand(0,4);
$fondo = $ima[$random];
?>
<html>
	<head>
	<title>Home</title>
	<link rel="stylesheet" href="CSS/home.css" type="text/css" />
	</head>
	<body style="background-image: url(images/<?php echo $fondo;?>.jpg)">		
</body>	
</html>