<?php 

function a�oNac($year,$minAge,$maxAge){
	$birthYear=$year-$minAge;
	echo '<select name="year">';
	for($i=0;$i<($maxAge-$minAge);$i++){
		echo'<option value="'.($birthYear-$i).'">'.($birthYear-$i).'</option>';
   	}
	echo '</select>';		
}
function day(){
	echo '<select name="day">';
	for($i=1;$i<=31;$i++){
		echo'<option value="'.$i.'">'.$i.'</option>';
   	}
	echo '</select>';		
}

function month(){
	$mes = array();
	$mes[1] = 'Enero';
	$mes[2] = 'Febrero';
	$mes[3] = 'Marzo';
	$mes[4] = 'Abril';
	$mes[5] = 'Mayo';
	$mes[6] = 'Junio';
	$mes[7] = 'Julio';
	$mes[8] = 'Agosto';
	$mes[9] = 'Septiembre';
	$mes[10] = 'Octubre';
	$mes[11] = 'Noviembre';
	$mes[12] = 'Diciembre';
	echo '<select name="month">';
	for($i=1;$i<=12;$i++){
		echo'<option value="'.$i.'">'.$mes[$i].'</option>';
   	}
	echo '</select>';		
}
?>