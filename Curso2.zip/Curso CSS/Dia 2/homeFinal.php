<?php 
include ("selectBox.php");
$ima = array();
$ima[0] = '100thWindow';
$ima[1] = 'Currupted';
$ima[2] = 'dance';
$ima[3] = 'Robot';
$ima[4] = 'Rocks';
$random = rand(0,4);
$fondo = $ima[$random];
?>
<html>
	<head>
	<title>Home</title>
	<link rel="stylesheet" href="CSS/home.css" type="text/css" />
	<script src="JS/validar.js" type="text/javascript"></script>
	<script src="JS/validarfinal.js" type="text/javascript"></script>
	</head>

	<body style="background-image: url(images/<?php echo $fondo;?>.jpg)">		
		<div id="Title"></div>
		<div id="logo" style="background-image: url(images/face.jpg)"></div>
		<div id="lopgin">
			<form name="loginForm" method="post" onSubmit="return valLoginForm(this.form)" action="login.php">
    			<input type="checkbox" name="recuerdame" value="SI"/>
    			<span class="loginletter">No cerrar sesi�n</span> 
    			<a href="olvido.php"><span class="loginletter">�Has olvidado tu contrase�a?</span></a>
    			<br>
    			<input type="text" name="login" value="escribir nombre de usuario" />
		        <input type="password" name="password" />
      			<br>
      			<input type="submit" name="Login" value="Enviar"/>
		  </form>
		</div>
		<div id="sideima" style="background-image: url(images/ini.jpg)"></div>
		<div id="register">
  		<span class="titleLetter">Reg�strate</span><br />
      	<span class="formLetter">Es gratis y cualquiera puede unirse.</span>
  		<form name="registerForm" method="post" onSubmit="return valRegisterForm(this.form)" action="registrarse.php" >
    		<table width="80%" border="1" align="center" bgcolor="#C5CDE0" id="Login">
      		<tr>
        		<td>Nombre: </td>
        		<td><input type="text" name="name"/></td>
      		</tr>
      		<tr>
        		<td>Apellidos:</td>
        		<td><input type="text" name="lastName"/></td>
      		</tr>
      		<tr>
        		<td>Direcci�n de correo electr�nico: </td>
        		<td><input type="text" name="email" /></td>
      		</tr>
      		<tr>
        		<td>Contrase�a nueva: </td>
        		<td><input type="password" name="password1"/></td>
      		</tr>
      		<tr>
      		<tr>
        		<td>Vuelva a Escribir la Contrase�a nueva: </td>
        		<td><input type="password" name="password2"/></td>
      		</tr>
      		<tr>
       			<td>Sexo: </td>
        		<td><select name="sex">
					<option value="masculino">Hombre</option>
					<option value="femenino">Mujer</option>
					</select>
				</td>
      		</tr>
      		<tr>
        		<td>Fecha de nacimiento</td>
        		<td><?php day(); echo ' '; month(); echo ' '; a�oNac(2010,13,85);?></td>
      		</tr>
	    </table>
    	<br><input type="submit" name="Register" value="Enviar" />
      </form>
   </div>
   <div id="footerback"></div>
   <div id="fakefooter" style="background-image: url(images/footer.jpg)";></div>
  </body>	
</html>