function valLoginForm(){
					var userName=document.loginForm.login.value
						if(userName==""){
							alert("Favor de capturar el nombre de Usuario")
							document.loginForm.login.focus()
							return false;
						}
					var pass=document.loginForm.password.value
						if(pass==""){
							alert("Favor de capturar la Contrase�a")
							document.loginForm.password.focus()
						return false;
						}
}
