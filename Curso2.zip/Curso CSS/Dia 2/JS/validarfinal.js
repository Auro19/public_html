function valRegisterForm(){
	var name=document.registerForm.name.value
		if(name==""){
			alert("Favor de capturar el nombre")
			document.registerForm.name.focus()
			return false;
		}
	var lastName=document.registerForm.lastName.value
	if(lastName==""){
		alert("Favor de capturar el Apellido")
		document.registerForm.lastName.focus()
		return false;
	}
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	
	   if(reg.test(email) == false) {
		   	  alert("El Correo es Invalido")
		      document.registerForm.email.focus();
		      return false;
		   }
	
	var pass1=document.registerForm.password1.value
	if(pass1==""){
		alert("Favor de capturar la Contrase�a")
		document.registerForm.password1.focus()
	return false;
	}
	
	var pass2=document.registerForm.password2.value
	if(pass2==""){
		alert("Favor de volver a capturar la Contrase�a")
		document.registerForm.password2.focus()
	return false;
	}
	
	if(pass1!=pass2){
		alert("Las contrase�as no coinciden, favor de volverlas a escribir.");
		document.registerForm.password1.focus()
		return false;
		}
	
	
	
	
}
