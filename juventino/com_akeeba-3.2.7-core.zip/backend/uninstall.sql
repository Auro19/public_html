DROP TABLE IF EXISTS `#__ak_profiles`;
DROP TABLE IF EXISTS `#__ak_stats`;
